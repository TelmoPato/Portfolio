import java.io.File

fun iniciaTerreno(terreno: Array<Array<String?>>, contadoresVerticais: Array<Int?>?, mostraLegendaHorizontal: Boolean): String {
    if (mostraLegendaHorizontal && contadoresVerticais == null) {
        //só com contadores
        return "     | " + criaLegendaHorizontal(terreno[0].size) + "\n"
    } else if (mostraLegendaHorizontal && contadoresVerticais != null) {
        //com contadores e com legenda
        return "       " + criaLegendaContadoresHorizontal(contadoresVerticais) + "\n     | " +
                criaLegendaHorizontal(terreno[0].size) + "\n"
    } else if (contadoresVerticais != null) {
        //só com contadores
        return "       " + criaLegendaContadoresHorizontal(contadoresVerticais) + "\n"
    }
    //sem contadores e sem legenda
    return ""
}

fun jogoDaTenda(terreno: Array<Array<String?>>, numLinhas: Int, numColunas: Int): String {
    do {
        do {
            //print do terreno
            print("\n" + criaTerreno(terreno, leContadoresDoFicheiro(numLinhas, numColunas, true),
                    leContadoresDoFicheiro(numLinhas, numColunas, false)) + "\nCoordenadas da tenda? (ex: 1,B)\n")
            //lê coordenadas
            var coordenadasStr = readln()
            if (coordenadasStr == "sair") {
                return "sair"
            }
            //repete até as coordenadas ficarem válidas
            while (processaCoordenadas(coordenadasStr, numLinhas, numColunas) == null) {
                print("Coordenadas invalidas\nCoordenadas da tenda? (ex: 1,B)\n")
                coordenadasStr = readln()
                if (coordenadasStr == "sair") {
                    return "sair"
                }
            }
            var parCoordenadas = processaCoordenadas(coordenadasStr, numLinhas, numColunas)
            //repete até as coordenadas ficarem válidas
            while (parCoordenadas != null && !colocaTenda(terreno, parCoordenadas)) {
                print("Tenda nao pode ser colocada nestas coordenadas\nCoordenadas da tenda? (ex: 1,B)\n")
                coordenadasStr = readln()
                if (coordenadasStr == "sair") {
                    return "sair"
                }
                //repete até as coordenadas ficarem válidas
                while (processaCoordenadas(coordenadasStr, numLinhas, numColunas) == null) {
                    print("Coordenadas invalidas\nCoordenadas da tenda? (ex: 1,B)\n")
                    coordenadasStr = readln()
                    if (coordenadasStr == "sair") {
                        return "sair"
                    }
                }
                parCoordenadas = processaCoordenadas(coordenadasStr, numLinhas, numColunas)
            }
        } while (parCoordenadas == null)
        val contadoresVerti = leContadoresDoFicheiro(numLinhas, numColunas, true)
        val contadoresHoriz = leContadoresDoFicheiro(numLinhas, numColunas, false)
    } while (!terminouJogo(terreno, contadoresVerti, contadoresHoriz))
    return ""
}

fun verificaDiaData(dia: Int, mes: Int, ano: Int, dataInvalida: String): String? {
    val menorDeIdade = "Menor de idade nao pode jogar"
    when (mes) {
        //ver dias para mes = 2
        2 -> {
            if ((ano % 4 == 0 && ano % 100 != 0) || ano % 400 == 0) {
                if (dia in 1..29) {
                    if (ano > 2004) {
                        return menorDeIdade
                    }
                    return null
                }
            } else {
                if (dia in 1..28) {
                    if (ano > 2004) {
                        return menorDeIdade
                    }
                    return null
                }
            }
        }
        //ver dias para meses com 31 dias
        1, 3, 5, 7, 8, 10, 12 -> {
            if (dia in 1..31) {
                if (ano > 2004) {
                    return menorDeIdade
                } else if (ano == 2004 && mes == 12) {
                    return menorDeIdade
                }
                return null
            }
        }
        //ver dias para meses com 30 dias
        4, 6, 9, 11 -> {
            if (dia in 1..30) {
                if (ano > 2004) {
                    return menorDeIdade
                } else if (ano == 2004 && mes == 11) {
                    return menorDeIdade
                }
                return null
            }
        }
    }
    return dataInvalida
}

fun criaMenu(): String = "\nBem vindo ao jogo das tendas\n\n1 - Novo jogo\n0 - Sair\n"

fun validaTamanhoMapa(numLinhas: Int, numColunas: Int): Boolean {
    return when {
        numLinhas == 6 && numColunas == 5 -> true
        numLinhas == 6 && numColunas == 6 -> true
        numLinhas == 8 && numColunas == 8 -> true
        numLinhas == 10 && numColunas == 10 -> true
        numLinhas == 8 && numColunas == 10 -> true
        numLinhas == 10 && numColunas == 8 -> true
        else -> false
    }
}

fun validaDataNascimento(data: String?): String? {
    val dataInvalida = "Data invalida"
    if (data != null) {
        if (data.length == 10) {
            if (data[2] == '-' && data[5] == '-') {
                val verificaDia = data[0].code in 48..51 && data[1].code in 48..57
                val verificaMes = data[3].code in 48..49 && data[4].code in 48..57
                val verificaAno = data[6].code in 49..50 && data[7].code in 48..57 && data[8].code in 48..57 && data[9].code in 48..57
                if (verificaDia) {
                    if (verificaMes) {
                        if (verificaAno) {
                            val partesData = data.split('-')
                            if (partesData[2].toInt() in 1900..2022) {
                                //verifica a data na funcao
                                return verificaDiaData(partesData[0].toInt(), partesData[1].toInt(), partesData[2].toInt(), dataInvalida)
                            }
                        }
                    }
                }
            }
        }
    }
    return dataInvalida
}

fun criaLegendaHorizontal(numColunas: Int): String {
    var legendaHorizontal = ""
    var countAlfabeto = 'A'
    var count = 0
    //enquanto o número de colunas já criadas for menor que o numero de colunas pedidas
    while (count < numColunas) {
        //caso não seja a última letra
        if (count < numColunas - 1) {
            //para a primeira letra não tem o caracter ' '
            if (count == 0) {
                legendaHorizontal += "$countAlfabeto |"
            } else {
                legendaHorizontal += " $countAlfabeto |"
            }
        } else {
            legendaHorizontal += " $countAlfabeto"
        }
        countAlfabeto++
        count++
    }
    return legendaHorizontal
}

fun processaCoordenadas(coordenadasStr: String?, numLines: Int, numColumns: Int): Pair<Int, Int>? {
    //ver se é null ou o tamanho menor que 3
    if (coordenadasStr != null && coordenadasStr.length >= 3) {
        var percorreCoordenadasStr = 0
        var posicaoVirgula = -1
        var coordenadasLinha = ""
        //percorre a string das coordenadas, vai guardando os valores na variavel coordenadasLinha até
        // encontrar a virgula, guarda a posição da virgula na variavrl posicaoVirgula
        while (percorreCoordenadasStr < coordenadasStr.length) {
            if (coordenadasStr[percorreCoordenadasStr] == ',') {
                //encontrou a virgula, termina o while ao igualar percorreCoordenadasStr
                // com o tamanho da String
                posicaoVirgula = percorreCoordenadasStr
                percorreCoordenadasStr = coordenadasStr.length
            } else {
                //verifica se o caracter a adicionar está entre 0..9
                //caso não esteja termina o ciclo
                if (coordenadasStr[percorreCoordenadasStr].code in 48..57) {
                    coordenadasLinha += coordenadasStr[percorreCoordenadasStr].toString()
                } else {
                    percorreCoordenadasStr = coordenadasStr.length
                }
            }
            percorreCoordenadasStr++
        }
        //caso tenha uma virgula guarda a coordenada da coluna na variavel
        // coordenadasColuna e verifica se as coordenadas estão de acordo com o terreno
        // e as coordenadasLinha não pode estar vazia
        if (posicaoVirgula != -1 && posicaoVirgula + 1 != coordenadasStr.length && coordenadasLinha != "") {
            val coordenadasColuna = coordenadasStr[posicaoVirgula + 1]
            if (coordenadasColuna.code in ('A').code until (('A').code + numColumns) && coordenadasLinha.toInt() in 1..numLines) {
                return Pair((coordenadasLinha.toInt() - 1), (coordenadasColuna.code - ('A').code))
            }
        }
    }
    return null
}

fun criaLegendaContadoresHorizontal(contadoresHorizontal: Array<Int?>): String {
    var legendaContadoresHorizontal = ""
    for (posicao in 0 until contadoresHorizontal.size) {
        //caso seja a primeira posição e diferente de null
        if (posicao == 0 && contadoresHorizontal[posicao] != null) {
            legendaContadoresHorizontal += "${contadoresHorizontal[posicao]}  "
        } else
        //caso seja a primeira posição e igual a null
            if (posicao == 0) {
                legendaContadoresHorizontal += "   "
            } else
            //caso não seja nem a primeira nem a última posição e diferente de null
                if (posicao < contadoresHorizontal.size - 1 && contadoresHorizontal[posicao] != null) {
                    legendaContadoresHorizontal += " ${contadoresHorizontal[posicao]}  "
                } else
                //caso não seja nem a primeira nem a última posição e igual de null
                    if (posicao < contadoresHorizontal.size - 1 && contadoresHorizontal[posicao] == null) {
                        legendaContadoresHorizontal += "    "
                    } else
                    //caso seja a última posição e diferente de null
                        if (contadoresHorizontal[posicao] != null) {
                            legendaContadoresHorizontal += " ${contadoresHorizontal[posicao]}"
                        } else
                        //caso seja a última posição e igual de null
                        {
                            legendaContadoresHorizontal += "  "
                        }
    }
    return legendaContadoresHorizontal
}

fun leContadoresDoFicheiro(numLines: Int, numColumns: Int, verticais: Boolean): Array<Int?> {
    //lê o respetivo ficheiro
    val ficheiro = File("${numLines}x${numColumns}.txt").readLines()
    if (verticais) {
        //cria um array com o size adquado, numLines
        val contadoresDoFicheiroVertical = Array<Int?>(numColumns) { null }
        //cria um array de Strings com os contadores
        val contadoresVertical = ficheiro[0].split(',')
        //transforma os 0 em null e guarda no array a dar return
        for (posicao in 0 until contadoresVertical.size) {
            if (contadoresVertical[posicao].toInt() != 0) {
                contadoresDoFicheiroVertical[posicao] = contadoresVertical[posicao].toInt()
            }
        }
        return contadoresDoFicheiroVertical
    } else {
        //cria um array com o size adquado, numColumns
        val contadoresDoFicheiroHorizontal = Array<Int?>(numLines) { null }
        //cria um array de Strings com os contadores
        val contadoresHorizontal = ficheiro[1].split(',')
        //transforma os 0 em null e guarda no array a dar return
        for (posicao in 0 until contadoresHorizontal.size) {
            if (contadoresHorizontal[posicao].toInt() != 0) {
                contadoresDoFicheiroHorizontal[posicao] = contadoresHorizontal[posicao].toInt()
            }
        }
        return contadoresDoFicheiroHorizontal
    }
}

fun leTerrenoDoFicheiro(numLines: Int, numColumns: Int): Array<Array<String?>> {
    //criar a matriz de acordo com o num de colunas e linhas
    val terreno: Array<Array<String?>> = Array(numLines) { Array(numColumns) { null } }
    //lê o respetivo ficheiro
    val ficheiro = File("${numLines}x${numColumns}.txt").readLines()
    //adicionar um A de acordo com o ficheiro
    for (linha in 2 until ficheiro.size) {
        val partes = ficheiro[linha].split(',')
        terreno[partes[0].toInt()][partes[1].toInt()] = "A"
    }
    return terreno
}

fun criaTerreno(terreno: Array<Array<String?>>, contadoresVerticais: Array<Int?>?, contadoresHorizontais: Array<Int?>?,
                mostraLegendaHorizontal: Boolean = true, mostraLegendaVertical: Boolean = true): String {
    val arvore = 9651.toChar()
    var terrenoFinal = iniciaTerreno(terreno, contadoresVerticais, mostraLegendaHorizontal)
    for (linha in 0 until terreno.size) {
        if (!mostraLegendaVertical && contadoresHorizontais == null) {
            terrenoFinal += "     |"
        } else if (mostraLegendaVertical && contadoresHorizontais == null) {
            if (linha < 9) {
                terrenoFinal += "   ${linha.plus(1)} |"
            } else {
                terrenoFinal += "  ${linha.plus(1)} |"
            }
        } else if (!mostraLegendaVertical && contadoresHorizontais != null) {
            if (contadoresHorizontais[linha] != null) {
                terrenoFinal += "${contadoresHorizontais[linha]}    |"
            } else {
                terrenoFinal += "     |"
            }
        } else if (mostraLegendaVertical && contadoresHorizontais != null) {
            if (contadoresHorizontais[linha] != null) {
                if (linha < 9) {
                    terrenoFinal += "${contadoresHorizontais[linha]}  ${linha.plus(1)} |"
                } else {
                    terrenoFinal += "${contadoresHorizontais[linha]} ${linha.plus(1)} |"
                }
            } else {
                if (linha < 9) {
                    terrenoFinal += "   ${linha.plus(1)} |"
                } else {
                    terrenoFinal += "  ${linha.plus(1)} |"
                }
            }
        }
        for (coluna in 0 until terreno[0].size) {
            if (coluna < terreno[0].size - 1) {
                if (terreno[linha][coluna] == null) {
                    terrenoFinal += "   |"
                } else if (terreno[linha][coluna] == "A") {
                    terrenoFinal += " $arvore |"
                } else if (terreno[linha][coluna] == "T") {
                    terrenoFinal += " T |"
                }
            } else {
                if (linha < terreno.size - 1) {
                    if (terreno[linha][coluna] == null) {
                        terrenoFinal += "  \n"
                    } else if (terreno[linha][coluna] == "A") {
                        terrenoFinal += " $arvore\n"
                    } else if (terreno[linha][coluna] == "T") {
                        terrenoFinal += " T\n"
                    }
                } else {
                    if (terreno[linha][coluna] == null) {
                        terrenoFinal += "  "
                    } else if (terreno[linha][coluna] == "A") {
                        terrenoFinal += " $arvore"
                    } else if (terreno[linha][coluna] == "T") {
                        terrenoFinal += " T"
                    }
                }
            }
        }
    }
    return terrenoFinal
}

fun temArvoreAdjacente(terreno: Array<Array<String?>>, coords: Pair<Int, Int>): Boolean {
    return when {
//verifica direita
        (terreno[0].size > coords.second + 1) && (terreno[coords.first][coords.second + 1] == "A") -> true
//verifica em baixo
        (terreno.size > coords.first + 1) && (terreno[coords.first + 1][coords.second] == "A") -> true
//verifica esquerda
        (0 <= coords.second - 1) && (terreno[coords.first][coords.second - 1] == "A") -> true
//verifica em cima
        (0 <= coords.first - 1) && (terreno[coords.first - 1][coords.second] == "A") -> true
        else -> false
    }
}

fun temTendaAdjacente(terreno: Array<Array<String?>>, coords: Pair<Int, Int>): Boolean {
    return when {
//verifica direita
        (terreno[0].size > coords.second + 1) && (terreno[coords.first][coords.second + 1] == "T") -> true
//verifica em baixo
        (terreno.size > coords.first + 1) && (terreno[coords.first + 1][coords.second] == "T") -> true
//verifica esquerda
        (0 <= coords.second - 1) && (terreno[coords.first][coords.second - 1] == "T") -> true
//verifica em cima
        (0 <= coords.first - 1) && (terreno[coords.first - 1][coords.second] == "T") -> true
//verifica em baixo direita
        (terreno[0].size > coords.second + 1) && (terreno.size > coords.first + 1) && (terreno[coords.first + 1][coords.second + 1] == "T") -> true
//verifica em baixo esquerda
        (0 <= coords.second - 1) && (terreno.size > coords.first + 1) && (terreno[coords.first + 1][coords.second - 1] == "T") -> true
//verifica em cima direita
        (terreno[0].size > coords.second + 1) && (0 <= coords.first - 1) && (terreno[coords.first - 1][coords.second + 1] == "T") -> true
//verifica em cima esquerda
        (0 <= coords.second - 1) && (0 <= coords.first - 1) && (terreno[coords.first - 1][coords.second - 1] == "T") -> true
        else -> false
    }
}

fun contaTendasColuna(terreno: Array<Array<String?>>, coluna: Int): Int {
    var tendasColuna = 0
//verifica se a coluna é válida
    if (coluna in 0 until terreno[0].size) {
//verifica linha a linha se aquela coluna tem um T
        for (linhaTerreno in terreno) {
            if (linhaTerreno[coluna] == "T") {
                tendasColuna++
            }
        }
    }
    return tendasColuna
}

fun contaTendasLinha(terreno: Array<Array<String?>>, linha: Int): Int {
    var tendasLinha = 0
//verifica se a linha é válida
    if (linha in 0 until terreno.size) {
//verifica se naquela linha tem algum T de acordo com a coluna
        for (coluna in 0 until terreno[linha].size) {
            if (terreno[linha][coluna] == "T") {
                tendasLinha++
            }
        }
    }
    return tendasLinha
}

fun colocaTenda(terreno: Array<Array<String?>>, coords: Pair<Int, Int>): Boolean {
    if (terreno[coords.first][coords.second] == null || terreno[coords.first][coords.second] == "T") {
        if (temArvoreAdjacente(terreno, coords)) {
            if (!temTendaAdjacente(terreno, coords)) {
//coloca a tenda
                if (terreno[coords.first][coords.second] == "T") {
                    terreno[coords.first][coords.second] = null
                } else {
                    terreno[coords.first][coords.second] = "T"
                }
                return true
            }
        }
    }
    return false
}

fun terminouJogo(terreno: Array<Array<String?>>, contadoresVerticais: Array<Int?>, contadoresHorizontais: Array<Int?>): Boolean {
//verifica se por cada linha o numero de Ts corresponde ao numero do contador
    for (linha in 0 until terreno.size) {
        val numTendasLinha = contaTendasLinha(terreno, linha)
        val contadorHori = contadoresHorizontais[linha] ?: 0
        if (numTendasLinha != contadorHori) {
            return false
        }
    }
//verifica se por cada coluna o numero de Ts corresponde ao numero do contador
    for (coluna in 0 until terreno[0].size) {
        val numTendasColuna = contaTendasColuna(terreno, coluna)
        val contadorVerti = contadoresVerticais[coluna] ?: 0
        if (numTendasColuna != contadorVerti) {
            return false
        }
    }
    return true
}

fun main() {
    do {
//variaveis; reset das variavies
        var opcao = -1
        var numLinhas = -1
        var numColunas = -1
        var dataNascimento: String? = null
//Menu; repete até ser 1, 0 ou sair
        while (opcao != 1 && opcao != 0) {
            println(criaMenu())
            val opcaoString = readln()
            if (opcaoString == "sair" || opcaoString == "0") {
                return
            }
            opcao = opcaoString.toIntOrNull() ?: -1
            if (opcao != 1) {
                println("Opcao invalida")
            }
        }
        if (opcao == 1) {
//repete até ser um número positivo ou sair
            while (numLinhas < 0) {
                println("Quantas linhas?")
                val numLinhasString = readln()
                if (numLinhasString == "sair") {
                    return
                }
                numLinhas = numLinhasString.toIntOrNull() ?: -1
                if (numLinhas < 0) {
                    println("Resposta invalida")
                }
            }
//repete até ser um número positivo ou sair
            while (numColunas < 0) {
                println("Quantas colunas?")
                val numColunasString = readln()
                if (numColunasString == "sair") {
                    return
                }
                numColunas = numColunasString.toIntOrNull() ?: -1
                if (numColunas < 0) {
                    println("Resposta invalida")
                }
            }
//Verifica Terreno
            if (validaTamanhoMapa(numLinhas, numColunas)) {
                val terreno = leTerrenoDoFicheiro(numLinhas, numColunas)
//Terreno é 10x10? -> ver idade
                if (numLinhas == 10 && numColunas == 10) {
                    //repete até ser uma data de nascimento válida
                    do {
                        println("Qual a sua data de nascimento? (dd-mm-yyyy)")
                        dataNascimento = readln()
                        if (dataNascimento == "sair") {
                            return
                        }
                        if (validaDataNascimento(dataNascimento) != null) {
                            println(validaDataNascimento(dataNascimento))
                        }
                    } while (validaDataNascimento(dataNascimento) == "Data invalida")
                }
//caso seja maior e num linhas e colunas diferente de 10
                if (validaDataNascimento(dataNascimento) != "Menor de idade nao pode jogar" || numLinhas != 10 && numColunas != 10) {
                    //termina a main numa função auxiliar
                    if (jogoDaTenda(terreno, numLinhas, numColunas) != "sair") {
                        println("\n" + criaTerreno(terreno, leContadoresDoFicheiro(numLinhas, numColunas, true),
                                leContadoresDoFicheiro(numLinhas, numColunas, false)) + "\nParabens! Terminou o jogo!")
                    } else {
                        return
                    }
                }
            } else {
                println("Terreno invalido\n")
            }
        }
    } while (opcao != 0)
}